#ifndef DONKEY_KONG_1981_TITLE_HH
#define DONKEY_KONG_1981_TITLE_HH

namespace title {
  void on_enter();
  void update(float dt_s);
  void draw();
  bool is_done();
}

#endif //DONKEY_KONG_1981_TITLE_HH
